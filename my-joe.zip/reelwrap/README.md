# Reelwrap

Type a Letterboxd username, get a swipeable "Wrapped" of that person's taste plus AI film recommendations.
Built with TMDB (film data) and Google Gemini (taste summary and recommendations).

## How it works
- `index.html`: the whole app screen (slides).
- `api/analyze.js`: reads the public Letterboxd RSS feed (latest ~50 diary films), enriches them with TMDB, asks Gemini for the summary and picks. Your keys live only here, as environment variables.

## Limits
- Only the latest ~50 diary entries are visible through the public feed. A full-history version needs the user's Letterboxd export (planned).
- Profiles must be public.

## Setup (no coding needed)
1. **TMDB key:** make a free account at themoviedb.org, then Settings, API, copy the "API Key" (the short one).
2. **Gemini key:** go to aistudio.google.com, sign in, "Get API key", create one.
3. **GitHub:** create a free account, click New repository, name it `reelwrap`, keep it Public, then "uploading an existing file", drag in everything from this folder (including the `api` folder), and Commit.
4. **Vercel:** sign up at vercel.com with your GitHub account, Add New, Project, import `reelwrap`. Before clicking Deploy, open Environment Variables and add `TMDB_API_KEY` and `GEMINI_API_KEY` with your keys. Deploy.
5. Open the link Vercel gives you, type a username, done.

Never paste real keys into any file on GitHub. Only into Vercel's Environment Variables box.
